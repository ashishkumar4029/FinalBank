/*
 * Angular COntroller to communicate with the RESTController
 */
//change loc according to the deployment server
var loc = "http://localhost:8081/ElysiumCorporation04/";

//Angular Module
var myApp = angular.module('myApp', ['ngRoute', 'ngMaterial', 'ngMessages']);
myApp.config(function ($routeProvider) {
	$routeProvider

	.when("/about", {
		controller: 'ServiceController',
		templateUrl: 'about.html'
	})
	.when("/funds", {
		controller: 'ServiceController',
		templateUrl: 'Fund2.htm'
	})
	.when("/services", {
		controller: 'ServiceController',
		templateUrl: 'Beneficiary.htm'
	})
	.when("/currentsummary", {
		controller: 'ServiceController',
		templateUrl: 'CurrentAccountSummary.htm'
	})
	.when("/savingssummary", {
		controller: 'ServiceController',
		templateUrl: 'SavingsAccountSummary.htm'
	})
	.when("/accType", {
		controller: 'ServiceController',
		templateUrl: 'AccountType.html'
	})
	.when("/statement", {
		controller: 'ServiceController',
		templateUrl: 'dateIndex.html'
	})
	.when("/Statement", {
		controller: 'ServiceController',
		templateUrl: 'Statement.html'
	})
	.when("/UserBeneficiary", {
		controller: 'ServiceController',
		templateUrl: 'UserBeneficiary.htm'
	})
	.when("/QuickTransfer", {
		controller: 'ServiceController',
		templateUrl: 'QuickTransfer.htm'
	})
	.when("/QuickTransfer(2)", {
		controller: 'ServiceController',
		templateUrl: 'QuickTransfer(2).html'
	})
	.when("/Fund1", {
		controller: 'ServiceController',
		templateUrl: 'Fund1.htm'
	})
	.when("/TransferFunds", {
		controller: 'ServiceController',
		templateUrl: 'TransferFunds.htm'
	})
	.when("/cPassword", {
		controller: 'ServiceController',
		templateUrl: 'ChangePassword.html'
	})

	.otherwise({
		redirectTo: '/try'
	})
});


myApp.controller('ServiceController', function ($scope, $http, $rootScope) {
	
	
	/*
	 * Variables for account opening form 
	 */
	$scope.accOpForm = {
			custNme: "",
			emailId: "",
			gender: "",
			aadharNo: "",
			panNo: "",
			dateOfBirth: "07-12-1996",
			mobileNo: "",
			branch: "",
			line1: "",
			line2: "",
			city: "",
			state: "",
			country: "",
			pincode: "",
			accType: ""
	};

	/*
	 * account opeing function
	 */
	$scope.add = function () {

		$http({
			method: 'POST',
			url: loc + 'rest/openAcc/' + $scope.accOpForm.custNme + '/' +
			$scope.accOpForm.emailId + '/' + $scope.accOpForm.mobileNo + '/' + $scope.accOpForm.dateOfBirth + '/' +
			$scope.accOpForm.gender + '/' + $scope.accOpForm.branch + '/' + $scope.accOpForm.line1 + '/' + $scope.accOpForm.line2 + '/' +
			$scope.accOpForm.city + '/' + $scope.accOpForm.state + '/' + $scope.accOpForm.pincode + '/' +
			$scope.accOpForm.country + '/' + $scope.accOpForm.aadharNo + '/' + $scope.accOpForm.panNo + '/'
			+ $scope.accOpForm.accType
		}).success(function (data) {
			alert("Your Account Opened"+data.accNo);
			window.location = loc + 'HomeScreen.html';

		}).error(function (error){
			alert("please complete the form")
		});
	}

	/*
	 * Variables for registering for online banking form
	 */
	$scope.regForm = {
			accNo: "",
			emailId: "",
			contact: "",
			pwd: "",
			mobileNo: "",

	};
	/*
	 * Online Banking Registration
	 */
	$scope.register = function () {

		$http({
			method: 'POST',
			url: loc + 'rest/register/' + $scope.regForm.accNo + '/' + $scope.regForm.mobileNo + '/' +
			$scope.regForm.emailId + '/' + $scope.regForm.pwd
		}).success(function (data) {

			alert("Please login");
			window.location = loc + 'HomeScreen.html';
		});
	}
	/*
	 * Variables for login form
	 */

	$scope.login = {
			username: "",
			password: ""
	};	

	/*
	 * Login Authenticate function
	 */
	$scope.authenticate = function () {


		$http({
			method: 'POST',
			url: loc + 'rest/authenticate/' + $scope.login.username + '/' + $scope.login.password

		}).success(function (data) {
			console.log('data');
			console.log(data);
			if (data == 0) {
				alert("User doesnt exist!");
			}
			else if (data == 1) {
				alert("Incorrect Password!");
			}
			else {
				//$rootScope.flag=1;
				alert("Successfully Logged In ");
				profilePageData();
				
			}


		}).error(function (error) {
			alert("Login Failed");

		});
	}
	
	
	refreshprofilePageData();
	
	function refreshprofilePageData() {
		//alert("in profile page data")
		$http({
			method: 'GET',
			url: loc + 'rest/profile.json'
		}).success(function (data) {
			//window.location = loc + 'UserProfile.html#/about';
			$scope.profile.custName = data.custNme;
			$scope.profile.mobileNo = data.mobileNo;
			$scope.profile.emailId = data.emailId;
			$scope.profile.aadhar = data.aadharNo;
			$scope.profile.pan = data.panNo;
			$scope.profile.dob = data.dateOfBirth;
			
		});
	}
	/*
	 * View Profile Function
	 */
	function profilePageData() {
		//alert("in profile page data")
		$http({
			method: 'GET',
			url: loc + 'rest/profile.json'
		}).success(function (data) {
			window.location = loc + 'UserProfile.html#/about';
			$scope.profile.custName = data.custNme;
			$scope.profile.mobileNo = data.mobileNo;
			$scope.profile.emailId = data.emailId;
			$scope.profile.aadhar = data.aadharNo;
			$scope.profile.pan = data.panNo;
			$scope.profile.dob = data.dateOfBirth;
			
		});
	}

	/*
	 * Variables for viewing profile
	 */
	$scope.profile = {
			custName: "",
			mobileNo: "",
			emailId: "",
			aadhar: "",
			pan: "",
			dob: ""
	};
	/*
	 * Variable for account summary
	 */
	$scope.acc = {
			type: ""
	}
	/*
	 * account summary function
	 */
	$scope.viewCurrentSummary = function () {
		$http({
			method: 'GET',
			url: loc + 'rest/accountSummary/Current'
		}).success(function (data) {
			if(data==null)
			{
				alert("No account summary available for selected account type");
			}else{
				//alert(data)
				$scope.acc.type="";
				//alert($scope.acc.type);
			}
			$scope.acc.type="";
			$rootScope.summaryData = data;

		});
	}
	$scope.viewSavingsSummary = function () {
		$http({
			method: 'GET',
			url: loc + 'rest/accountSummary/Savings' 
		}).success(function (data) {
			if(data==null)
			{
				alert("No account summary available for selected account type");
			}else{
				//alert(data)
				$scope.acc.type="";
				alert($scope.acc.type);
			}
			$scope.acc.type="";
			$rootScope.summaryData = data;

		});
	}
	/*
	 * Variable for adding beneficiary form
	 */
	$scope.benForm = {
			benName: "",
			ifsc: "",
			accType: "",
			accNo: "",
			bank: ""


	};
	/*
	 * adding beneficiary function
	 */
	$scope.addBen = function () {

		$http({
			method: 'POST',
			url: loc + 'rest/addBeneficiary/' + $scope.benForm.benName + '/' + $scope.benForm.accNo + '/' + $scope.benForm.bank + '/' +
			$scope.benForm.accType + '/' + $scope.benForm.ifsc
		}).success(function (data) {

			//window.location = loc + 'UserProfile.html#/about';
			profilePageData();


		});

	}

	/*
	 * Variables for deleting beneficiary
	 */
	$scope.del = {
			bAcno: ""



	};
	/*
	 * delete beneficiary function
	 */
	$scope.delBen = function (c) {
		//alert(c.benAccNo)
		$http({
			method: 'DELETE',
			url: loc + 'rest/delBeneficiary/' + c.benAccNo
		}).success(function (data) {


			if(data==1){
				$window.location.reload();
			}
			


		});

	}
	
	/*
	 * variable for show beneficiary
	 */
	showPageData();

	function showPageData() {
		$http({
			method: 'GET',
			url: loc + 'rest/showBen.json'
		}).success(function (data) {

			$scope.benData = data;


		});

	}


	$scope.del = {
			bAcno: ""



	};
	
	/*
	 *Inter fund transfer 
	 */
	$scope.interForm = {
			accType: "",
			benAccNo: "",
			amount: "",
			benName: "",
			benBank: "",

	};




	$scope.intertransfer = function () {

		//alert("in inter transfer");
		$http({
			method: 'POST',
			url: loc + 'rest/interTransfer/' + $scope.interForm.accType + '/' + $scope.interForm.benAccNo + '/' + $scope.interForm.amount + '/' + $scope.interForm.benName + '/' + $scope.interForm.benBank

		}).success(function (data) {
			if (data == 0) {
				alert("Beneficiary doesnt exist!");
			}
			else if (data == 1) {
				alert("Insufficient balance!");
			}
			else {
				alert("Success");
			}
			window.location = loc + 'UserProfile.html#/about';
			
		});

	}

	/*
	 * InteraFund Transfer
	 */
	$scope.intraForm = {
			accType: "",
			benAccNo: "",
			amount: "",
			benName: "",
			benBank: "",

	};
	$scope.intratransfer = function () {

		//alert("in intra transfer");
		$http({
			method: 'POST',
			url: loc + 'rest/intraTransfer/' + $scope.intraForm.accType + '/' + $scope.intraForm.benAccNo + '/' + $scope.intraForm.amount + '/' + $scope.intraForm.benName + '/' + $scope.intraForm.benBank

		}).success(function (data) {
			if (data == 0) {
				alert("Beneficiary doesnt exist!");
			}
			else if (data == 1) {
				alert("Insufficient balance!");
			}
			else {
				alert("Success");

			}
			window.location = loc + 'UserProfile.html#/about';

			

		});

	}
	
	/*
	 * E-statement
	 */
	function dateController($scope) {
		$scope.strtDate = new Date();
		$scope.endDate = new Date();
		$scope.month = new Date();
		$scope.maxDate = new Date(
				$scope.endDate.getFullYear(),
				$scope.endDate.getMonth(),
				$scope.endDate.getDate());
	}
	$scope.myVar = $scope.myVar ? true : true;




	$scope.sateform = {

			date1: "",
			date2: ""
	}

	$scope.statement = function () {


		$http({
			method: 'GET',
			url: loc + 'rest/accountStatementByDate/' + $scope.sateform.date1 + '/' + $scope.sateform.date2

		}).success(function (data) {

			$rootScope.statementData = data;

		});

	}
});



/*
 * Controller for Managing Transactions
 */
myApp.controller("interFundTransfer", function ($scope, $http, $rootScope) {

	





}
);
myApp.controller("intraFundTransfer", function ($scope, $http, $rootScope) {

	



}
);

/*
 * Controller for Login Authentication
 */
myApp.controller("Authenticate", function ($scope, $http, $rootScope) {


}
);



/*
 * Controller for Displaying Customer Profile
 */
myApp.controller("ShowProfile", function ($scope, $http, $rootScope) {

	_refreshPageData();




}
);

/*
 * Controller for displaying e statement
 */
myApp.controller("StatementController", function ($scope, $http, $rootScope) {




	

});




