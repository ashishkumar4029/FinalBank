package services;

import java.util.Date;
import java.util.List;

import entities.AccountDetails;
import entities.AuthenticationDetails;
import entities.BeneficiaryDetails;
import entities.CustomerAddress;
import entities.CustomerDetails;
import entities.TransactionDetails;
import exceptions.CustException;

public interface Services {
	
	void addBeneficiary(BeneficiaryDetails beneficiary)throws CustException;
	List<BeneficiaryDetails> showBeneficiaries(Integer custId)throws CustException;
	Integer deleteBeneficiary(String benAccNo)throws CustException;
	List<TransactionDetails> statementForMonth(Integer custId, Date date)throws CustException;
	List<TransactionDetails> statementForSixMonth(Integer custId, Date date)throws CustException;
	List<TransactionDetails> statementForDates(Integer custId, Date date1, Date date2)throws CustException;
	Integer addCust(CustomerDetails c)throws CustException;
	void addAddress(CustomerAddress a)throws CustException;
	Integer addAcc(AccountDetails acc)throws CustException;
	public void interBankTrans(Integer accNo, Integer benAccNo, Float amount, Integer custId, TransactionDetails trans)throws CustException;
	public void intraBankTrans(Integer accNo, Integer benAccNo, Float amount, Integer custId, TransactionDetails trans)throws CustException;
	String getIfsc(String branch)throws CustException;
	void registerUser(AuthenticationDetails authDet)throws CustException;
	Boolean validateTrans(Integer custId, String benName, String benBank, Integer benAccNo)throws CustException;
	Integer getAcc(Integer custId, String accType)throws CustException;
	Integer getCustId(String email)throws CustException;
	List<String> getIdPass(Integer custId)throws CustException;
	public CustomerDetails getCust(Integer custId) throws CustException;
	Integer getCustomer(String email) throws CustException;
	List<Object> summary(Integer custId, String accType) ;
	boolean validAmount(Integer accNo, Float amount);
	Integer checkBenAcc(Integer custId, String baccNo) throws CustException;
}
