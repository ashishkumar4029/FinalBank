package daos;

import java.util.List;

import entities.BeneficiaryDetails;
import exceptions.CustException;

public interface BeneficiaryDao {
	void addBeneficiary(BeneficiaryDetails beneficiary) throws CustException;
	BeneficiaryDetails getBeneficiary(Integer custId) throws CustException;
	void updateBeneficiary(BeneficiaryDetails beneficiary) throws CustException;
	Integer removeBeneficiary(String benAccNo) throws CustException;
	List<BeneficiaryDetails> getBeneficiaries(Integer custId) throws CustException;
	Boolean validateBen(Integer custId, String benName, String benBank, Integer benAccNo) throws CustException;
	Integer getBenAcc(Integer custId, String baccNo) throws CustException;
}
