package entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


public class IfscCodes {

	
	private String branchCity;
	
	
	private String ifscCode;
	
	public IfscCodes() {
		super();
	}

	public IfscCodes(String branchCity, String ifscCode) {
		super();
		this.branchCity = branchCity;
		this.ifscCode = ifscCode;
	}

	public String getBranchCity() {
		return branchCity;
	}

	public void setBranchCity(String branchCity) {
		this.branchCity = branchCity;
	}

	public String getIfscCode() {
		return ifscCode;
	}

	public void setIfscCode(String ifscCode) {
		this.ifscCode = ifscCode;
	}

	@Override
	public String toString() {
		return "IfscCodes [branchCity=" + branchCity + ", ifscCode=" + ifscCode + "]";
	}
	
	
	
}
