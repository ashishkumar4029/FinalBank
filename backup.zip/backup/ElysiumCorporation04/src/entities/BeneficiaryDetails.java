package entities;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


public class BeneficiaryDetails {
	
	
	
	private Integer benAccNo;
	
	
	private Integer custId;
	
	
	private String benBank;
	
	
	private String benAccType;
	
	
	private String benIfsc;
	
	
	private String benName;
	
	
	private Date lastUpdate = new Date();
	
	public BeneficiaryDetails()
	{
		super();
	}

	public BeneficiaryDetails(Integer benAccNo, Integer custId, String benBank, String benAccType, String benIfsc,
			String benName, Date lastUpdate) {
		super();
		this.benAccNo = benAccNo;
		this.custId = custId;
		this.benBank = benBank;
		this.benAccType = benAccType;
		this.benIfsc = benIfsc;
		this.benName = benName;
		this.lastUpdate = lastUpdate;
	}

	public Integer getBenAccNo() {
		return benAccNo;
	}

	public void setBenAccNo(Integer baccNo) {
		this.benAccNo = baccNo;
	}

	

	public Integer getCustId() {
		return custId;
	}

	public void setCustId(Integer custId) {
		this.custId = custId;
	}

	public String getBenBank() {
		return benBank;
	}

	public void setBenBank(String benBank) {
		this.benBank = benBank;
	}

	public String getBenAccType() {
		return benAccType;
	}

	public void setBenAccType(String benAccType) {
		this.benAccType = benAccType;
	}

	public String getBenIfsc() {
		return benIfsc;
	}

	public void setBenIfsc(String benIfsc) {
		this.benIfsc = benIfsc;
	}

	public String getBenName() {
		return benName;
	}

	public void setBenName(String benName) {
		this.benName = benName;
	}

	public Date getLastUpdate() {
		return lastUpdate;
	}

	public void setLastUpdate(Date lastUpdate) {
		this.lastUpdate = lastUpdate;
	}

	@Override
	public String toString() {
		return "BeneficiaryDetails [benAccNo=" + benAccNo + ", custId=" + custId + ", benBank=" + benBank
				+ ", benAccType=" + benAccType + ", benIfsc=" + benIfsc + ", benName=" + benName + ", lastUpdate="
				+ lastUpdate + "]";
	}

	
	
	
	
	
	
}

