package entities;

import java.util.Date;


public class CustomerDetails {
	
	
	private Integer custId;
	
	private String custNme;
	
	
	private String mobileNo;
	

	private String emailId;
	
	
	private String gender;
	
	
	private String aadharNo;
	
	
	private String panNo;
	
	
	private String dateOfBirth;

	//@OneToOne(mappedBy ="cust", fetch = FetchType.EAGER) // take parameter of many to one
	//private CustomerAddress address;
	
	public CustomerDetails()
	{
		super();
	}

	public CustomerDetails(Integer custId, String custNme, String mobileNo, String emailId, String gender,
			String aadharNo, String panNo, String dateOfBirth) {
		super();
		this.custId = custId;
		this.custNme = custNme;
		this.mobileNo = mobileNo;
		this.emailId = emailId;
		this.gender = gender;
		this.aadharNo = aadharNo;
		this.panNo = panNo;
		this.dateOfBirth = dateOfBirth;
		//this.address = address;
	}

	public Integer getCustId() {
		return custId;
	}

	public void setCustId(Integer custId) {
		this.custId = custId;
	}

	public String getCustNme() {
		return custNme;
	}

	public void setCustNme(String custNme) {
		this.custNme = custNme;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getAadharNo() {
		return aadharNo;
	}

	public void setAadharNo(String aadharNo) {
		this.aadharNo = aadharNo;
	}

	public String getPanNo() {
		return panNo;
	}

	public void setPanNo(String panNo) {
		this.panNo = panNo;
	}

	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(String date) {
		this.dateOfBirth = date;
	}

	
	/*public CustomerAddress getAddress() {
		return address;
	}

	public void setAddress(CustomerAddress address) {
		this.address = address;
	}*/

	@Override
	public String toString() {
		return "CustomerDetails [custId=" + custId + ", custNme=" + custNme + ", mobileNo=" + mobileNo + ", emailId="
				+ emailId + ", gender=" + gender + ", aadharNo=" + aadharNo + ", panNo=" + panNo + ", dateOfBirth="
				+ dateOfBirth + "]";
	}

}
