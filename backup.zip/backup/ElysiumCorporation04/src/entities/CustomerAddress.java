package entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;


public class CustomerAddress {
	
	
	private Integer custId;
	
	
	private String line1;
	
	
	private String line2;
	
	
	private String city;
	

	private String state;
	
	
	private String country;
	

	private String pincode;
	
	public CustomerAddress()
	{
		super();
	}
	
	//@OneToOne
	//@JoinColumn(name="CUST_ID")
	//private CustomerDetails cust;

	public String getLine1() {
		return line1;
	}

	public void setLine1(String line1) {
		this.line1 = line1;
	}

	public String getLine2() {
		return line2;
	}

	public void setLine2(String line2) {
		this.line2 = line2;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getPincode() {
		return pincode;
	}

	public void setPincode(String pincode) {
		this.pincode = pincode;
	}

	/*public CustomerDetails getCust() {
		return cust;
	}

	public void setCust(CustomerDetails cust) {
		this.cust = cust;
	}*/

	public Integer getCustId() {
		return custId;
	}

	public void setCustId(Integer custId) {
		this.custId = custId;
	}

	public CustomerAddress(Integer custId, String line1, String line2, String city, String state, String country,
			String pincode) {
		super();
		this.custId = custId;
		this.line1 = line1;
		this.line2 = line2;
		this.city = city;
		this.state = state;
		this.country = country;
		this.pincode = pincode;
		//this.cust = cust;
	}

	@Override
	public String toString() {
		return "CustomerAddress [cust_id=" + custId + ", line1=" + line1 + ", line2=" + line2 + ", city=" + city
				+ ", state=" + state + ", country=" + country + ", pincode=" + pincode + "]";
	}

	
	
}
