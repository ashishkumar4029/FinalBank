package daos;

import entities.CustomerDetails;
import exceptions.CustException;

public interface CustomerDao {
	Integer addCustomer(CustomerDetails cust) throws CustException;
	CustomerDetails getCustomer(Integer custId) throws CustException;
	void updateProfile(CustomerDetails cust) throws CustException;
	void deleteCustomer(Integer custId) throws CustException;
	Integer getCustId(String emailId) throws CustException;
}
