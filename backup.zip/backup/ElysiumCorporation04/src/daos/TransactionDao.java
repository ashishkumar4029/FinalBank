package daos;

import java.util.Date;
import java.util.List;

import entities.TransactionDetails;
import exceptions.CustException;

public interface TransactionDao {
	Integer addTransaction(TransactionDetails trans)throws CustException;	
	TransactionDetails getTransaction(Integer transId)throws CustException;
	Float getLastTransAmount(Integer accNo)throws CustException;
	Date getLastTransDate(Integer accNo)throws CustException;
	List<TransactionDetails> detailByMonth(Integer custId, Date date)throws CustException;
	List<TransactionDetails> detailBySixMonth(Integer custId, Date date)throws CustException;
	List<TransactionDetails> detailByDate(Integer custId, Date date1, Date date2)throws CustException;
}
