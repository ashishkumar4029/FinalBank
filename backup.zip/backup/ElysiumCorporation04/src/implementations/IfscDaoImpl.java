package implementations;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import configuration.HibernateUtil;
import daos.IfscDao;
import entities.IfscCodes;
import exceptions.CustException;

@Repository("ifscDao")
public class IfscDaoImpl implements IfscDao{
	
	@Autowired
	private SessionFactory factory;
	
	@Override
	public void addBranch(IfscCodes ifsc) throws CustException {
		
		Session session = factory.openSession();
		Transaction tn = session.getTransaction();
		try {
			tn.begin();
			session.persist(ifsc);
			tn.commit();
		}
		catch(HibernateException e){
			if(tn!=null)
			{
				tn.rollback();
				throw new CustException("Cannot connect to DataBase");
			}
		}
		session.close();
	}
	
	@Override
	public String getIfsc(String branch) {
		Session session = factory.openSession();
		IfscCodes ifsc= (IfscCodes) session.get(IfscCodes.class, branch);
		String reqIfsc = ifsc.getIfscCode();
		session.close();
		return reqIfsc;
	}
}
