package implementations;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import configuration.HibernateUtil;
import daos.CustomerDao;
import entities.CustomerDetails;
import exceptions.CustException;

@Repository("custDao")
public class CustomerDaoImpl implements CustomerDao {
	
	@Autowired
	private SessionFactory factory;
	
	@Override
	public Integer addCustomer(CustomerDetails cust) throws CustException {
		
		Session session = factory.openSession();
		Transaction tn = session.getTransaction();
		Integer ci = null;
		try {
			tn.begin();
			ci = (int) session.save(cust);
			tn.commit();
		}
		catch(HibernateException e){
			if(tn!=null)
			{

				tn.rollback();
				throw new CustException("Cannot connect to DataBase");
			}
		}
		session.close();
		return ci;
	}

	@Override
	public CustomerDetails getCustomer(Integer custId) {
		Session session = factory.openSession();
		CustomerDetails cust= (CustomerDetails) session.get(CustomerDetails.class, custId);
		session.close();
		return cust;
	}

	@Override
	public void updateProfile(CustomerDetails cust) throws CustException {
		Session session = factory.openSession();
		Transaction tn = session.getTransaction();
		try {
			tn.begin();
			session.update(cust);
			tn.commit();
		}
		catch(HibernateException e){
			if(tn!=null)
			{
	
				tn.rollback();
				throw new CustException("Cannot connect to DataBase");
			}
		}
		session.close();
		
	}

	@Override
	public void deleteCustomer(Integer custId) throws CustException {
		Session session = factory.openSession();
		Transaction tn = session.getTransaction();
		try {
			tn.begin();
			CustomerDetails cust= (CustomerDetails) session.get(CustomerDetails.class, custId);
			session.delete(cust);
			tn.commit();
		}
		catch(HibernateException e){
			if(tn!=null)
			{

				tn.rollback();
				throw new CustException("Cannot connect to DataBase");
			}
		}
		session.close();
		
	}

	@Override
	public Integer getCustId(String emailId) throws CustException {
		Session session = factory.openSession();
		Transaction tn = session.getTransaction();
		Integer custId = 0;
		try {
			tn.begin();
			System.out.println(emailId);
			String cust = "select a.custId from CustomerDetails a where a.emailId = :email";
			Query query2 = session.createQuery(cust);
		    query2.setParameter("email",emailId);
			List<Integer> custIds = query2.list();
			custId = custIds.get(0);
			//CustomerDetails cust= (CustomerDetails) session.get(CustomerDetails.class, emailId);
			System.out.println(custId);
			//custId = cust.getCustId();
			tn.commit();
		}
		catch(HibernateException e){
			if(tn!=null)
			{
				tn.rollback();
				throw new CustException("Cannot connect to DataBase");
			}
		}
		session.close();
		return custId;
	}
}
