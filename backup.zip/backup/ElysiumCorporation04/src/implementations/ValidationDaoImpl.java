package implementations;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import configuration.HibernateUtil;
import daos.ValidationDao;
import entities.ValidationDetails;
import exceptions.CustException;

@Repository("valDao")
public class ValidationDaoImpl implements ValidationDao{
	
	@Autowired
	private SessionFactory factory;
	
	@Override
	public void addDetails(ValidationDetails det) throws CustException {
		
		Session session = factory.openSession();
		Transaction tn = session.getTransaction();
		try {
			tn.begin();
			session.persist(det);
			tn.commit();
		}
		catch(HibernateException e){
			if(tn!=null)
			{
				tn.rollback(); 
				throw new CustException("Cannot connect to DataBase");
			}
		}
		session.close();
	}
	
	@Override
	public List<String> getNameAndPan(String aadhar) {
		Session session = factory.openSession();
		List<String> namePan = null;
		ValidationDetails val= (ValidationDetails) session.get(ValidationDetails.class, aadhar);
		namePan.add(val.getCustName());
		namePan.add(val.getPanNo());
		session.close();
		return namePan;
	}
	
	@Override
	public String isChecked(String aadhar)
	{
		Session session = factory.openSession();
		ValidationDetails val= (ValidationDetails) session.get(ValidationDetails.class, aadhar);
		session.close();
		return val.getStatus();
	}
	
	@Override
	public void updateCheck(String aadhar) throws CustException
	{
		Session session = factory.openSession();
		Transaction tn = session.getTransaction();
		try {
			tn.begin();
			String update = "update ValidationDetails a set a.status = :newstatus where a.aadharNo = :aadhar";
		    Query query2 = session.createQuery(update);
		    query2.setParameter("newstatus",true);
		    query2.setParameter("aadhar",aadhar);
			query2.executeUpdate();
			tn.commit();
		}
		catch(HibernateException e){
			if(tn!=null)
			{
				tn.rollback();
				throw new CustException("Cannot connect to DataBase");
			}
		}
		session.close();
	}
}
