package implementations;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.text.ParseException;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import daos.TransactionDao;
import entities.TransactionDetails;
import exceptions.CustException;

@Repository("transDao")
public class TransactionDaoImpl implements TransactionDao{

	@Autowired
	private SessionFactory factory;
	
	@Override
	public Integer addTransaction(TransactionDetails trans) throws CustException {
		Session session = factory.openSession();
		Transaction tn = session.getTransaction();
		Integer transId = 0;
		try {
			tn.begin();
			transId = (Integer) session.save(trans);
			tn.commit();
		}
		catch(HibernateException e){
			if(tn!=null)
			{
				tn.rollback();
				throw new CustException("Cannot connect to DataBase");
			}
		}
		session.close();
		return transId;
	}

	@Override
	public TransactionDetails getTransaction(Integer transId) {
		Session session = factory.openSession();
		TransactionDetails trans= (TransactionDetails) session.get(TransactionDetails.class, transId);
		session.close();
		return trans;
	}

	@Override
	public Float getLastTransAmount(Integer accNo) throws CustException {
		Session session = factory.openSession();
		Transaction tn = session.getTransaction();
		Float latestAmount = 0f;
		List<Float> am= null;
		try {
			tn.begin();
			String getAmount = "Select t.amount from TransactionDetails t where t.transferDate = (select max(tt.transferDate) from TransactionDetails tt where tt.accNo =:acc_No) ";
			Query query = session.createQuery(getAmount);
			query.setParameter("acc_No",accNo);
		    am = query.list();
		    System.out.println(am);
		    latestAmount = am.get(0);
			tn.commit();
		}
		catch(HibernateException e){
			if(tn!=null)
			{
				tn.rollback();
				throw new CustException("Cannot connect to DataBase");
			}
			
	}
		session.close();
		return latestAmount;
	}

	@Override
	public Date getLastTransDate(Integer accNo) throws CustException {
		Session session = factory.openSession();
		Transaction tn = session.getTransaction();
		Date lastTransDate = null;
		List<Date> am= null;
		try {
			tn.begin();
			String getAmount = "select max(tt.transferDate) from TransactionDetails tt where tt.accNo =:acc_no ";
			Query query = session.createQuery(getAmount);
			query.setParameter("acc_no",accNo);
		    am = query.list();
		    lastTransDate = am.get(0);
			tn.commit();
		}
		catch(HibernateException e){
			if(tn!=null)
			{
				tn.rollback();
				throw new CustException("Cannot connect to DataBase");
			}
			
	}
		session.close();
		return lastTransDate;
	}

	@Override
	public List<TransactionDetails> detailByDate(Integer custId, Date date1, Date date2) throws CustException {
		
		
		Session session = factory.openSession();
		Transaction tn = session.getTransaction();
		List<TransactionDetails> am= null;
		/*SimpleDateFormat sm = new SimpleDateFormat("dd-MMM-yy");
		String strDate = sm.format(date1);
        String endDate = sm.format(date2);*/
//        strDate="1-FEB-18";
//        endDate="25-FEB-18";
		try {
			tn.begin();
			String getAmount = "from TransactionDetails t where t.custId = :custId AND t.transferDate BETWEEN  :startDate AND :endDate";
			Query query = session.createQuery(getAmount);
			query.setParameter("custId",custId);
			query.setParameter("startDate",date1);
			query.setParameter("endDate",date2);
		    am = query.list();
			tn.commit();
		}
		catch(HibernateException e){
			if(tn!=null)
			{
				tn.rollback();
				throw new CustException("Cannot connect to DataBase");
			}
			
	}
		session.close();
		return am;	
	}

	@Override
	public List<TransactionDetails> detailByMonth(Integer custId, Date date) throws CustException {
		
		Session session = factory.openSession();
		Transaction tn = session.getTransaction();
		List<TransactionDetails> am= null;
		Date newDate = addDays(date, 30);
		try {
			
			tn.begin();
			String getAmount = "Select  from TransactionDetails t where t.custId = :custId AND t.transferDate BETWEEN  :stDate AND :edDate";
			Query query = session.createQuery(getAmount);
			query.setParameter("custId",custId);
			query.setParameter("stDate",(java.sql.Date)date);
			query.setParameter("edDate",(java.sql.Date)newDate);
		    am = query.list();
			tn.commit();
		}
		catch( HibernateException e1){
			if(tn!=null)
			{
				tn.rollback();
				throw new CustException("Cannot connect to DataBase");
			}
			
	}
		session.close();
		return am;
		
		
		
		
	}

	public static Date addDays(Date date, int days) {
		GregorianCalendar cal = new GregorianCalendar();
		cal.setTime(date);
		cal.add(Calendar.DATE, days);
				
		return cal.getTime();
	}
	
	@Override
	public List<TransactionDetails> detailBySixMonth(Integer custId, Date date) throws CustException {
		
		Session session = factory.openSession();
		Transaction tn = session.getTransaction();
		List<TransactionDetails> am= null;
		Date newDate = addDays(date, 180);
		try 
		{
			
			tn.begin();
			String getAmount = "Select from TransactionDetails t where t.custId = :custId AND t.transferDate BETWEEN  :startDate AND :endDate";
			Query query = session.createQuery(getAmount);
			query.setParameter("custId",custId);
			query.setParameter("startDate",(java.sql.Date) date);
			query.setParameter("endDate",(java.sql.Date) newDate);
		    am = query.list();
		   
			tn.commit();
		}
		catch(HibernateException e){
			if(tn!=null)
			{
				tn.rollback();
				throw new CustException("Cannot connect to DataBase");
			}
			
	}
		session.close();
		return am;
	
	}

}
